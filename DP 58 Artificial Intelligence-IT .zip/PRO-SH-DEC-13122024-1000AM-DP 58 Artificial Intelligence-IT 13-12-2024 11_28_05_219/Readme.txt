Software Name: Jupyter Notebook (Python Version 3.9.0)

Step 1: Open Jupyter Notebook software

Step 2: Click upload and select the "physics.ipynb" file and the click open. After that click on Upload option to upload the file.

Step 3: Place the "physics.owl" at same location where "physics.ipynb" file 

Step 4: There are two way to run the software file
	
	1. Click on the Kernel option and then click on Run option (To 	single single cell at a time)

	2. Click on Click on the Kernel option and then click on Restart and Run all option (To run all the cell in one time)

Step 5: All the outputs will display in the "physics.ipynb" after running the code.